Hi there!

This folder is dedicated to optional content for you to run on your server. These are optional because they require changes to server that otherwise could not be done automagically.

I tried to make these modular so servers could pick and chose what features they wanted without having to edit/remove/add/whatever to files. Each module contains a README.txt file that will give you important information on said module.

Enjoy!
- Bryan
